package com.spring.config;

public class Configure {

    public static final String ROOT_DIR = System.getProperty("user.dir");
    public static final String UPLOAD_DIR = System.getProperty("user.dir") + "/upload/";
    public static final String FILE_PREFIX = "/upload/";
}
