package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Lunbotu;
import org.springframework.stereotype.Repository;

@Repository
public interface LunbotuMapper extends MapperBase<Lunbotu> {}
