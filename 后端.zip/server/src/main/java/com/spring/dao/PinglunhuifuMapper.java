package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Pinglunhuifu;
import org.springframework.stereotype.Repository;

@Repository
public interface PinglunhuifuMapper extends MapperBase<Pinglunhuifu> {}
