package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Yiqingshangbao;
import org.springframework.stereotype.Repository;

@Repository
public interface YiqingshangbaoMapper extends MapperBase<Yiqingshangbao> {}
