package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Fenbutu;
import org.springframework.stereotype.Repository;

@Repository
public interface FenbutuMapper extends MapperBase<Fenbutu> {}
