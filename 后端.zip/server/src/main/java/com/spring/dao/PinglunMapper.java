package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Pinglun;
import org.springframework.stereotype.Repository;

@Repository
public interface PinglunMapper extends MapperBase<Pinglun> {}
