package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Xinwenxinxi;
import org.springframework.stereotype.Repository;

@Repository
public interface XinwenxinxiMapper extends MapperBase<Xinwenxinxi> {}
