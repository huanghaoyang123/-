package com.spring.dao;

import com.spring.config.MapperBase;
import com.spring.entity.Shoucang;
import org.springframework.stereotype.Repository;

@Repository
public interface ShoucangMapper extends MapperBase<Shoucang> {}
